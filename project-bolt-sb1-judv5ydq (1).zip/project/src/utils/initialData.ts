import { Song, Puzzle, Event, MarkingCriteria, WarriorMember } from '../types';

export const initialSongs: Song[] = [
  {
    id: '1',
    title: 'Faded',
    artist: 'Alan Walker',
    embedUrl: 'https://www.youtube.com/embed/60ItHLz5WEA',
  },
  {
    id: '2',
    title: 'Alone',
    artist: 'Alan Walker',
    embedUrl: 'https://www.youtube.com/embed/1-xGerv5FOk',
  },
  {
    id: '3',
    title: 'Darkside',
    artist: 'Alan Walker ft. Au/Ra and Tomine Harket',
    embedUrl: 'https://www.youtube.com/embed/M-P4QBt-FWw',
  },
  {
    id: '4',
    title: 'On My Way',
    artist: 'Alan Walker, Sabrina Carpenter & Farruko',
    embedUrl: 'https://www.youtube.com/embed/dhYOPzcsbGM',
  }
];

export const initialPuzzles: Puzzle[] = [
  {
    id: '1',
    question: 'I speak without a mouth and hear without ears. I have no body, but come alive with the wind. What am I?',
    answer: 'An echo',
    difficulty: 'medium'
  },
  {
    id: '2',
    question: 'What has keys but no locks, space but no room, and you can enter but not go inside?',  
    answer: 'A keyboard',
    difficulty: 'easy'
  },
  {
    id: '3',
    question: 'I am not alive, but I grow; I don\'t have lungs, but I need air; I don\'t have a mouth, but water kills me. What am I?',
    answer: 'Fire',
    difficulty: 'hard'
  },
  {
    id: '4',
    question: 'The more you take, the more you leave behind. What am I?',
    answer: 'Footsteps',
    difficulty: 'medium'
  }
];

export const initialEvents: Event[] = [
  {
    id: '1',
    title: 'RWS Annual Meet',
    description: 'Join us for our annual community gathering with exciting activities, workshops, and networking opportunities.',
    date: '2024-12-15',
    place: 'Community Center, Downtown',
    time: '10:00 AM'
  },
  {
    id: '2',
    title: 'Gaming Tournament',
    description: 'Epic gaming tournament featuring multiple games and amazing prizes for winners.',
    date: '2024-12-20',
    place: 'Gaming Arena, Tech Hub',
    time: '2:00 PM'
  },
  {
    id: '3',
    title: 'Tech Workshop',
    description: 'Learn the latest technologies and development practices in our hands-on workshop.',
    date: '2025-01-05',
    place: 'Innovation Lab, University',
    time: '9:00 AM'
  }
];

export const initialMarkingCriteria: MarkingCriteria[] = [
  {
    id: '1',
    name: 'Event Participation',
    description: 'Active participation in community events and activities',
    maxScore: 10,
    category: 'participation',
    isActive: true,
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    name: 'Creative Contribution',
    description: 'Original ideas, creative solutions, and innovative thinking',
    maxScore: 15,
    category: 'creativity',
    isActive: true,
    createdAt: new Date().toISOString()
  },
  {
    id: '3',
    name: 'Technical Skills',
    description: 'Demonstration of technical expertise and problem-solving abilities',
    maxScore: 20,
    category: 'technical',
    isActive: true,
    createdAt: new Date().toISOString()
  },
  {
    id: '4',
    name: 'Leadership',
    description: 'Taking initiative, mentoring others, and leading by example',
    maxScore: 15,
    category: 'leadership',
    isActive: true,
    createdAt: new Date().toISOString()
  },
  {
    id: '5',
    name: 'Team Collaboration',
    description: 'Working effectively with others and contributing to team success',
    maxScore: 10,
    category: 'collaboration',
    isActive: true,
    createdAt: new Date().toISOString()
  }
];

export const initialWarriors: WarriorMember[] = [
  {
    id: '1',
    name: 'Alex Johnson',
    email: 'alex@rws.com',
    joinDate: '2024-01-15',
    isActive: true
  },
  {
    id: '2',
    name: 'Sarah Chen',
    email: 'sarah@rws.com',
    joinDate: '2024-02-20',
    isActive: true
  },
  {
    id: '3',
    name: 'Marcus Rodriguez',
    email: 'marcus@rws.com',
    joinDate: '2024-03-10',
    isActive: true
  },
  {
    id: '4',
    name: 'Emma Thompson',
    email: 'emma@rws.com',
    joinDate: '2024-04-05',
    isActive: true
  },
  {
    id: '5',
    name: 'David Kim',
    email: 'david@rws.com',
    joinDate: '2024-05-12',
    isActive: true
  }
];