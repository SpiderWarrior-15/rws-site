export interface Song {
  id: string;
  title: string;
  artist: string;
  embedUrl: string;
  thumbnail?: string;
}

export interface Puzzle {
  id: string;
  question: string;
  answer: string;
  difficulty: 'easy' | 'medium' | 'hard';
  isRevealed?: boolean;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  place: string;
  time?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: string;
  isRead: boolean;
}

export interface AdminUser {
  username: string;
  password: string;
}

export interface MarkingCriteria {
  id: string;
  name: string;
  description: string;
  maxScore: number;
  category: 'participation' | 'creativity' | 'technical' | 'leadership' | 'collaboration';
  isActive: boolean;
  createdAt: string;
}

export interface WarriorMember {
  id: string;
  name: string;
  email: string;
  joinDate: string;
  avatar?: string;
  isActive: boolean;
}

export interface Mark {
  id: string;
  warriorId: string;
  criteriaId: string;
  score: number;
  feedback?: string;
  markedBy: string;
  markedAt: string;
  eventId?: string;
}

export interface MarkingSummary {
  warriorId: string;
  totalScore: number;
  averageScore: number;
  markCount: number;
  categoryScores: Record<string, number>;
  lastMarked: string;
}