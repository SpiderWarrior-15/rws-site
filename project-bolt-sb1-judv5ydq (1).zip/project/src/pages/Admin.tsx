import React, { useState } from 'react';
import { Shield, Users, Music, Brain, Calendar, Mail, Eye, EyeOff, Lock, Star, Award, Plus, Edit, Trash2, BarChart3 } from 'lucide-react';
import { GlassCard } from '../components/GlassCard';
import { AnimatedButton } from '../components/AnimatedButton';
import { WarriorCard } from '../components/WarriorCard';
import { MarkingModal } from '../components/MarkingModal';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { ContactMessage, AdminUser, MarkingCriteria, WarriorMember, Mark, MarkingSummary } from '../types';
import { initialMarkingCriteria, initialWarriors } from '../utils/initialData';

export const Admin: React.FC = () => {
  const [messages] = useLocalStorage<ContactMessage[]>('rws-messages', []);
  const [criteria, setCriteria] = useLocalStorage<MarkingCriteria[]>('rws-criteria', initialMarkingCriteria);
  const [warriors, setWarriors] = useLocalStorage<WarriorMember[]>('rws-warriors', initialWarriors);
  const [marks, setMarks] = useLocalStorage<Mark[]>('rws-marks', []);
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'warriors' | 'criteria' | 'analytics'>('overview');
  const [isMarkingModalOpen, setIsMarkingModalOpen] = useState(false);
  const [selectedWarrior, setSelectedWarrior] = useState<WarriorMember | null>(null);
  const [isAddingCriteria, setIsAddingCriteria] = useState(false);
  const [newCriteria, setNewCriteria] = useState({
    name: '',
    description: '',
    maxScore: 10,
    category: 'participation' as const
  });

  // Simple admin authentication (in a real app, this would be more secure)
  const adminCredentials: AdminUser = {
    username: 'admin',
    password: 'rws2024'
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginData.username === adminCredentials.username && 
        loginData.password === adminCredentials.password) {
      setIsAuthenticated(true);
    } else {
      alert('Invalid credentials');
    }
  };

  const handleMarkWarrior = (warrior: WarriorMember) => {
    setSelectedWarrior(warrior);
    setIsMarkingModalOpen(true);
  };

  const handleSubmitMark = (markData: Omit<Mark, 'id' | 'markedAt'>) => {
    const newMark: Mark = {
      ...markData,
      id: Date.now().toString(),
      markedAt: new Date().toISOString()
    };
    setMarks([...marks, newMark]);
  };

  const handleAddCriteria = () => {
    if (newCriteria.name && newCriteria.description) {
      const criteria: MarkingCriteria = {
        id: Date.now().toString(),
        ...newCriteria,
        isActive: true,
        createdAt: new Date().toISOString()
      };
      setCriteria(prev => [...prev, criteria]);
      setNewCriteria({ name: '', description: '', maxScore: 10, category: 'participation' });
      setIsAddingCriteria(false);
    }
  };

  const toggleCriteriaStatus = (id: string) => {
    setCriteria(prev => prev.map(c => 
      c.id === id ? { ...c, isActive: !c.isActive } : c
    ));
  };

  const deleteCriteria = (id: string) => {
    setCriteria(prev => prev.filter(c => c.id !== id));
    setMarks(prev => prev.filter(m => m.criteriaId !== id));
  };

  // Calculate marking summaries
  const getMarkingSummary = (warriorId: string): MarkingSummary => {
    const warriorMarks = marks.filter(m => m.warriorId === warriorId);
    const totalScore = warriorMarks.reduce((sum, mark) => sum + mark.score, 0);
    const averageScore = warriorMarks.length > 0 ? totalScore / warriorMarks.length : 0;
    
    const categoryScores: Record<string, number> = {};
    warriorMarks.forEach(mark => {
      const criteriaData = criteria.find(c => c.id === mark.criteriaId);
      if (criteriaData) {
        categoryScores[criteriaData.category] = (categoryScores[criteriaData.category] || 0) + mark.score;
      }
    });

    return {
      warriorId,
      totalScore,
      averageScore,
      markCount: warriorMarks.length,
      categoryScores,
      lastMarked: warriorMarks.length > 0 ? warriorMarks[warriorMarks.length - 1].markedAt : ''
    };
  };

  const adminStats = [
    {
      icon: Users,
      title: 'Total Warriors',
      value: warriors.length.toString(),
      color: 'from-purple-600 to-blue-600'
    },
    {
      icon: Music,
      title: 'Songs',
      value: '24',
      color: 'from-blue-600 to-teal-600'
    },
    {
      icon: Brain,
      title: 'Puzzles',
      value: '18',
      color: 'from-teal-600 to-green-600'
    },
    {
      icon: Calendar,
      title: 'Events',
      value: '12',
      color: 'from-green-600 to-yellow-600'
    },
    {
      icon: Mail,
      title: 'Messages',
      value: messages.length.toString(),
      color: 'from-yellow-600 to-red-600'
    },
    {
      icon: Star,
      title: 'Total Marks',
      value: marks.length.toString(),
      color: 'from-red-600 to-purple-600'
    }
  ];

  const unreadMessages = messages.filter(msg => !msg.isRead);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen pt-20 pb-12 flex items-center justify-center">
        <div className="max-w-md w-full mx-4">
          <GlassCard className="p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl mb-4">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
                Admin Access
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Please login to access the admin panel
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Username
                </label>
                <input
                  type="text"
                  value={loginData.username}
                  onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                  className="w-full px-4 py-3 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white"
                  placeholder="Enter username"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    className="w-full px-4 py-3 pr-12 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white"
                    placeholder="Enter password"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <AnimatedButton
                type="submit"
                variant="primary"
                size="lg"
                icon={Lock}
                className="w-full"
              >
                Login to Admin Panel
              </AnimatedButton>
            </form>

            <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <p className="text-sm text-blue-400 text-center">
                <strong>Demo Credentials:</strong><br />
                Username: admin<br />
                Password: rws2024
              </p>
            </div>
          </GlassCard>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <div>
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-purple-600/20 to-blue-600/20 backdrop-blur-md border border-purple-500/30 mb-4">
              <Shield className="w-5 h-5 text-purple-400 mr-2" />
              <span className="text-sm font-medium text-purple-400">Admin Dashboard</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Control Center
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400 mt-2">
              Manage your Royal Warriors Squad community
            </p>
          </div>
          <AnimatedButton
            variant="ghost"
            onClick={() => setIsAuthenticated(false)}
          >
            Logout
          </AnimatedButton>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'warriors', label: 'Warriors', icon: Users },
            { id: 'criteria', label: 'Marking Criteria', icon: Award },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'
                  : 'bg-white/10 dark:bg-gray-800/50 text-gray-700 dark:text-gray-300 hover:bg-white/20 dark:hover:bg-gray-700/50'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-12">
              {adminStats.map((stat) => (
                <GlassCard key={stat.title} className="p-6 text-center">
                  <div className={`inline-flex items-center justify-center w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl mb-4`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-gray-800 dark:text-white mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {stat.title}
                  </div>
                </GlassCard>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <GlassCard className="p-6 text-center hover:scale-105 transition-transform duration-300 cursor-pointer">
                <Music className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
                  Manage Songs
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Add, edit, or remove songs from Warriors' Picks
                </p>
              </GlassCard>

              <GlassCard className="p-6 text-center hover:scale-105 transition-transform duration-300 cursor-pointer">
                <Brain className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
                  Manage Puzzles
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Create and manage brain teasers for the community
                </p>
              </GlassCard>

              <GlassCard className="p-6 text-center hover:scale-105 transition-transform duration-300 cursor-pointer">
                <Calendar className="w-12 h-12 text-teal-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
                  Manage Events
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Schedule and organize community events
                </p>
              </GlassCard>

              <GlassCard className="p-6 text-center hover:scale-105 transition-transform duration-300 cursor-pointer">
                <Mail className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
                  View Messages
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Review contact form submissions
                </p>
                {unreadMessages.length > 0 && (
                  <div className="mt-2 inline-flex items-center px-2 py-1 rounded-full bg-red-500/20 text-red-400 text-xs">
                    {unreadMessages.length} unread
                  </div>
                )}
              </GlassCard>
            </div>

            {/* Recent Messages */}
            <GlassCard className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                  Recent Messages
                </h2>
                {unreadMessages.length > 0 && (
                  <div className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-sm font-medium">
                    {unreadMessages.length} new
                  </div>
                )}
              </div>

              {messages.length === 0 ? (
                <div className="text-center py-8">
                  <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">No messages yet</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {messages.slice(0, 10).map((message) => (
                    <div
                      key={message.id}
                      className={`p-4 rounded-lg border transition-all duration-300 ${
                        message.isRead
                          ? 'bg-white/5 dark:bg-gray-800/20 border-white/10 dark:border-gray-700/30'
                          : 'bg-blue-500/10 border-blue-500/30'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-gray-800 dark:text-white">
                            {message.name}
                          </h4>
                          <p className="text-sm text-purple-600 dark:text-purple-400">
                            {message.email}
                          </p>
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          {new Date(message.timestamp).toLocaleDateString()}
                        </div>
                      </div>
                      <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                        {message.message}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </GlassCard>
          </>
        )}

        {/* Warriors Tab */}
        {activeTab === 'warriors' && (
          <div>
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                Warriors Management
              </h2>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {warriors.filter(w => w.isActive).length} active warriors
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {warriors.map(warrior => (
                <WarriorCard
                  key={warrior.id}
                  warrior={warrior}
                  summary={getMarkingSummary(warrior.id)}
                  onMark={handleMarkWarrior}
                />
              ))}
            </div>
          </div>
        )}

        {/* Criteria Tab */}
        {activeTab === 'criteria' && (
          <div>
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                Marking Criteria
              </h2>
              <AnimatedButton
                variant="primary"
                icon={Plus}
                onClick={() => setIsAddingCriteria(true)}
              >
                Add Criteria
              </AnimatedButton>
            </div>

            {/* Add Criteria Form */}
            {isAddingCriteria && (
              <GlassCard className="p-6 mb-8">
                <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
                  Add New Marking Criteria
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      value={newCriteria.name}
                      onChange={(e) => setNewCriteria({ ...newCriteria, name: e.target.value })}
                      className="w-full px-4 py-2 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white"
                      placeholder="Criteria name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Max Score
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={newCriteria.maxScore}
                      onChange={(e) => setNewCriteria({ ...newCriteria, maxScore: Number(e.target.value) })}
                      className="w-full px-4 py-2 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Category
                    </label>
                    <select
                      value={newCriteria.category}
                      onChange={(e) => setNewCriteria({ ...newCriteria, category: e.target.value as any })}
                      className="w-full px-4 py-2 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white"
                    >
                      <option value="participation">Participation</option>
                      <option value="creativity">Creativity</option>
                      <option value="technical">Technical</option>
                      <option value="leadership">Leadership</option>
                      <option value="collaboration">Collaboration</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Description
                    </label>
                    <textarea
                      value={newCriteria.description}
                      onChange={(e) => setNewCriteria({ ...newCriteria, description: e.target.value })}
                      className="w-full px-4 py-2 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white resize-none"
                      rows={3}
                      placeholder="Describe what this criteria measures..."
                    />
                  </div>
                </div>
                <div className="flex space-x-4 mt-6">
                  <AnimatedButton
                    variant="primary"
                    onClick={handleAddCriteria}
                  >
                    Add Criteria
                  </AnimatedButton>
                  <AnimatedButton
                    variant="ghost"
                    onClick={() => {
                      setIsAddingCriteria(false);
                      setNewCriteria({ name: '', description: '', maxScore: 10, category: 'participation' });
                    }}
                  >
                    Cancel
                  </AnimatedButton>
                </div>
              </GlassCard>
            )}

            {/* Criteria List */}
            <div className="grid md:grid-cols-2 gap-6">
              {criteria.map(criteriaItem => (
                <GlassCard key={criteriaItem.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">
                        {criteriaItem.name}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        {criteriaItem.description}
                      </p>
                      <div className="flex items-center space-x-4 text-sm">
                        <span className="text-purple-600 dark:text-purple-400">
                          Max Score: {criteriaItem.maxScore}
                        </span>
                        <span className="capitalize text-blue-600 dark:text-blue-400">
                          {criteriaItem.category}
                        </span>
                      </div>
                    </div>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                      criteriaItem.isActive 
                        ? 'bg-green-500/20 text-green-400' 
                        : 'bg-gray-500/20 text-gray-400'
                    }`}>
                      {criteriaItem.isActive ? 'Active' : 'Inactive'}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <AnimatedButton
                      variant="secondary"
                      size="sm"
                      onClick={() => toggleCriteriaStatus(criteriaItem.id)}
                    >
                      {criteriaItem.isActive ? 'Deactivate' : 'Activate'}
                    </AnimatedButton>
                    <AnimatedButton
                      variant="ghost"
                      size="sm"
                      icon={Trash2}
                      onClick={() => deleteCriteria(criteriaItem.id)}
                      className="text-red-500 hover:text-red-600"
                    >
                      Delete
                    </AnimatedButton>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-8">
              Performance Analytics
            </h2>
            
            {/* Top Performers */}
            <GlassCard className="p-6 mb-8">
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-6">
                Top Performers
              </h3>
              <div className="space-y-4">
                {warriors
                  .map(warrior => ({
                    warrior,
                    summary: getMarkingSummary(warrior.id)
                  }))
                  .sort((a, b) => b.summary.totalScore - a.summary.totalScore)
                  .slice(0, 5)
                  .map(({ warrior, summary }, index) => (
                    <div key={warrior.id} className="flex items-center space-x-4 p-4 bg-white/5 dark:bg-gray-800/20 rounded-lg">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                        index === 0 ? 'bg-yellow-500' : 
                        index === 1 ? 'bg-gray-400' : 
                        index === 2 ? 'bg-amber-600' : 'bg-purple-500'
                      }`}>
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-800 dark:text-white">
                          {warrior.name}
                        </h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {summary.markCount} marks • Avg: {summary.averageScore.toFixed(1)}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-purple-600 dark:text-purple-400">
                          {summary.totalScore}
                        </div>
                        <div className="text-xs text-gray-500">
                          Total Score
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </GlassCard>

            {/* Category Breakdown */}
            <GlassCard className="p-6">
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-6">
                Category Performance
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
                {['participation', 'creativity', 'technical', 'leadership', 'collaboration'].map(category => {
                  const categoryMarks = marks.filter(mark => {
                    const criteriaData = criteria.find(c => c.id === mark.criteriaId);
                    return criteriaData?.category === category;
                  });
                  const totalScore = categoryMarks.reduce((sum, mark) => sum + mark.score, 0);
                  const avgScore = categoryMarks.length > 0 ? totalScore / categoryMarks.length : 0;

                  return (
                    <div key={category} className="text-center p-4 bg-white/5 dark:bg-gray-800/20 rounded-xl">
                      <div className="text-2xl font-bold text-purple-600 dark:text-purple-400 mb-2">
                        {avgScore.toFixed(1)}
                      </div>
                      <div className="text-sm font-medium text-gray-800 dark:text-white capitalize mb-1">
                        {category}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        {categoryMarks.length} marks
                      </div>
                    </div>
                  );
                })}
              </div>
            </GlassCard>
          </div>
        )}
      </div>

      {/* Marking Modal */}
      {selectedWarrior && (
        <MarkingModal
          isOpen={isMarkingModalOpen}
          onClose={() => {
            setIsMarkingModalOpen(false);
            setSelectedWarrior(null);
          }}
          warrior={selectedWarrior}
          criteria={criteria}
          onSubmitMark={handleSubmitMark}
        />
      )}
    </div>
  );
};