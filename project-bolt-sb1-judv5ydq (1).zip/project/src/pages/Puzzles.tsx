import React, { useState } from 'react';
import { Plus, Edit, Trash2, Brain, CheckCircle, XCircle } from 'lucide-react';
import { GlassCard } from '../components/GlassCard';
import { AnimatedButton } from '../components/AnimatedButton';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Puzzle } from '../types';
import { initialPuzzles } from '../utils/initialData';

export const Puzzles: React.FC = () => {
  const [puzzles, setPuzzles] = useLocalStorage<Puzzle[]>('rws-puzzles', initialPuzzles);
  const [flippedCards, setFlippedCards] = useState<Set<string>>(new Set());
  const [solvedPuzzles, setSolvedPuzzles] = useState<Set<string>>(new Set());
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingPuzzle, setEditingPuzzle] = useState<Puzzle | null>(null);
  const [newPuzzle, setNewPuzzle] = useState({ question: '', answer: '', difficulty: 'medium' as const });

  const handleFlipCard = (id: string) => {
    setFlippedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const handleAnswerSubmit = (puzzleId: string) => {
    const puzzle = puzzles.find(p => p.id === puzzleId);
    const userAnswer = userAnswers[puzzleId]?.toLowerCase().trim();
    const correctAnswer = puzzle?.answer.toLowerCase().trim();

    if (userAnswer === correctAnswer) {
      setSolvedPuzzles(prev => new Set([...prev, puzzleId]));
    }
  };

  const handleAddPuzzle = () => {
    if (newPuzzle.question && newPuzzle.answer) {
      const puzzle: Puzzle = {
        id: Date.now().toString(),
        ...newPuzzle
      };
      setPuzzles([...puzzles, puzzle]);
      setNewPuzzle({ question: '', answer: '', difficulty: 'medium' });
      setIsAddingNew(false);
    }
  };

  const handleEditPuzzle = (puzzle: Puzzle) => {
    if (editingPuzzle?.id === puzzle.id) {
      const updatedPuzzles = puzzles.map(p => 
        p.id === puzzle.id ? { ...puzzle, ...newPuzzle } : p
      );
      setPuzzles(updatedPuzzles);
      setEditingPuzzle(null);
      setNewPuzzle({ question: '', answer: '', difficulty: 'medium' });
    } else {
      setEditingPuzzle(puzzle);
      setNewPuzzle({ 
        question: puzzle.question, 
        answer: puzzle.answer, 
        difficulty: puzzle.difficulty 
      });
    }
  };

  const handleDeletePuzzle = (id: string) => {
    setPuzzles(puzzles.filter(puzzle => puzzle.id !== id));
    setFlippedCards(prev => {
      const newSet = new Set(prev);
      newSet.delete(id);
      return newSet;
    });
    setSolvedPuzzles(prev => {
      const newSet = new Set(prev);
      newSet.delete(id);
      return newSet;
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-500 border-green-500/30 bg-green-500/10';
      case 'medium': return 'text-yellow-500 border-yellow-500/30 bg-yellow-500/10';
      case 'hard': return 'text-red-500 border-red-500/30 bg-red-500/10';
      default: return 'text-gray-500 border-gray-500/30 bg-gray-500/10';
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-purple-600/20 to-blue-600/20 backdrop-blur-md border border-purple-500/30 mb-6">
            <Brain className="w-5 h-5 text-purple-400 mr-2" />
            <span className="text-sm font-medium text-purple-400">Challenge Your Mind</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Brain Puzzles
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Test your wit with our collection of mind-bending puzzles and riddles
          </p>
        </div>

        {/* Add New Puzzle Button */}
        <div className="flex justify-center mb-8">
          <AnimatedButton
            variant="primary"
            icon={Plus}
            onClick={() => setIsAddingNew(true)}
          >
            Add New Puzzle
          </AnimatedButton>
        </div>

        {/* Add/Edit Puzzle Form */}
        {(isAddingNew || editingPuzzle) && (
          <GlassCard className="p-6 mb-8 max-w-2xl mx-auto">
            <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
              {editingPuzzle ? 'Edit Puzzle' : 'Add New Puzzle'}
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Question
                </label>
                <textarea
                  value={newPuzzle.question}
                  onChange={(e) => setNewPuzzle({ ...newPuzzle, question: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white resize-none"
                  rows={4}
                  placeholder="Enter your puzzle question..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Answer
                </label>
                <input
                  type="text"
                  value={newPuzzle.answer}
                  onChange={(e) => setNewPuzzle({ ...newPuzzle, answer: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white"
                  placeholder="Enter the answer"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Difficulty
                </label>
                <select
                  value={newPuzzle.difficulty}
                  onChange={(e) => setNewPuzzle({ ...newPuzzle, difficulty: e.target.value as 'easy' | 'medium' | 'hard' })}
                  className="w-full px-4 py-2 bg-white/10 dark:bg-gray-800/50 backdrop-blur-md border border-white/20 dark:border-gray-700/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
              <div className="flex space-x-4">
                <AnimatedButton
                  variant="primary"
                  onClick={editingPuzzle ? () => handleEditPuzzle(editingPuzzle) : handleAddPuzzle}
                >
                  {editingPuzzle ? 'Update Puzzle' : 'Add Puzzle'}
                </AnimatedButton>
                <AnimatedButton
                  variant="ghost"
                  onClick={() => {
                    setIsAddingNew(false);
                    setEditingPuzzle(null);
                    setNewPuzzle({ question: '', answer: '', difficulty: 'medium' });
                  }}
                >
                  Cancel
                </AnimatedButton>
              </div>
            </div>
          </GlassCard>
        )}

        {/* Puzzles Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {puzzles.map((puzzle) => (
            <div key={puzzle.id} className="relative group">
              <GlassCard className="h-80 cursor-pointer perspective-1000">
                <div 
                  className={`relative w-full h-full transition-transform duration-700 transform-style-preserve-3d ${
                    flippedCards.has(puzzle.id) ? 'rotate-y-180' : ''
                  }`}
                  onClick={() => handleFlipCard(puzzle.id)}
                >
                  {/* Front Side */}
                  <div className="absolute inset-0 w-full h-full backface-hidden p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(puzzle.difficulty)}`}>
                          {puzzle.difficulty.toUpperCase()}
                        </span>
                        {solvedPuzzles.has(puzzle.id) && (
                          <CheckCircle className="w-6 h-6 text-green-500" />
                        )}
                      </div>
                      <p className="text-gray-800 dark:text-white text-lg leading-relaxed">
                        {puzzle.question}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        Click to reveal answer
                      </p>
                      <Brain className="w-8 h-8 text-purple-500 mx-auto animate-pulse" />
                    </div>
                  </div>

                  {/* Back Side */}
                  <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 p-6 flex flex-col justify-between bg-gradient-to-br from-purple-600/20 to-blue-600/20">
                    <div className="text-center">
                      <h4 className="text-lg font-bold text-gray-800 dark:text-white mb-4">Answer:</h4>
                      <p className="text-xl font-medium text-purple-600 dark:text-purple-400 mb-6">
                        {puzzle.answer}
                      </p>
                    </div>
                    <div className="space-y-3">
                      <input
                        type="text"
                        value={userAnswers[puzzle.id] || ''}
                        onChange={(e) => setUserAnswers({ ...userAnswers, [puzzle.id]: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2 bg-white/20 dark:bg-gray-800/50 backdrop-blur-md border border-white/30 dark:border-gray-700/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-800 dark:text-white text-sm"
                        placeholder="Your answer..."
                      />
                      <AnimatedButton
                        variant="primary"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAnswerSubmit(puzzle.id);
                        }}
                        className="w-full"
                      >
                        Submit
                      </AnimatedButton>
                    </div>
                  </div>
                </div>
              </GlassCard>

              {/* Admin Controls */}
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex space-x-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleEditPuzzle(puzzle);
                  }}
                  className="p-2 bg-blue-500/80 hover:bg-blue-600/80 text-white rounded-lg transition-colors duration-300"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeletePuzzle(puzzle.id);
                  }}
                  className="p-2 bg-red-500/80 hover:bg-red-600/80 text-white rounded-lg transition-colors duration-300"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {puzzles.length === 0 && (
          <div className="text-center py-12">
            <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-600 dark:text-gray-400 mb-2">
              No puzzles yet
            </h3>
            <p className="text-gray-500 dark:text-gray-500">
              Add your first puzzle to challenge the warriors!
            </p>
          </div>
        )}
      </div>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .transform-style-preserve-3d {
          transform-style: preserve-3d;
        }
        .backface-hidden {
          backface-visibility: hidden;
        }
        .rotate-y-180 {
          transform: rotateY(180deg);
        }
      `}</style>
    </div>
  );
};