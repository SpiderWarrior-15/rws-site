import React from 'react';
import { Github, Twitter, Instagram, Youtube, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const socialLinks = [
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Youtube, href: '#', label: 'YouTube' },
  ];

  return (
    <footer className="bg-white/5 dark:bg-gray-900/20 backdrop-blur-md border-t border-white/10 dark:border-gray-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          {/* Copyright */}
          <div className="flex items-center space-x-2 text-gray-600 dark:text-gray-400">
            <span>© All Rights Reserved RWS — Created by</span>
            <span className="font-semibold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Faizy
            </span>
            <Heart className="w-4 h-4 text-red-500 animate-pulse" />
          </div>

          {/* Social Links */}
          <div className="flex items-center space-x-4">
            {socialLinks.map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                className="p-2 rounded-lg bg-white/10 dark:bg-gray-800/50 hover:bg-white/20 dark:hover:bg-gray-700/50 transition-all duration-300 hover:scale-110 group"
              >
                <Icon className="w-5 h-5 text-gray-600 dark:text-gray-400 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors duration-300" />
              </a>
            ))}
          </div>
        </div>

        {/* Tagline */}
        <div className="mt-6 pt-6 border-t border-white/10 dark:border-gray-800/30 text-center">
          <p className="text-lg font-medium bg-gradient-to-r from-purple-600 via-blue-600 to-teal-600 bg-clip-text text-transparent">
            Unleashing Passion, Power & Purpose
          </p>
        </div>
      </div>
    </footer>
  );
};